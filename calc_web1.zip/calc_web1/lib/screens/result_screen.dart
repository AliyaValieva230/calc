import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../logic/calculator.dart';
import '../logic/currency.dart';

class ResultScreen extends StatelessWidget {
  final String type;
  const ResultScreen({super.key, required this.type});

  @override
  Widget build(BuildContext context) {
    final state = GoRouterState.of(context);
    final q = state.uri.queryParameters;

    String title;
    String content;
    Widget? errorWidget;

    if (type == 'calculator') {
      final result = calculate(q['a'], q['op'], q['b']);
      title = 'Результат вычисления';

      if (result is CalcSuccess) {
        content = '${q['a'] ?? ''} ${q['op'] ?? ''} ${q['b'] ?? ''} = ${result.value}';
      } else if (result is CalcFailure) {
        content = 'Ошибка: ${result.message}';
        errorWidget = Text(
          'Проверьте введённые данные',
          style: TextStyle(color: Theme.of(context).colorScheme.error),
        );
      } else {
        content = 'Неизвестная ошибка';
      }
    } else if (type == 'converter') {
      final result = convertCurrency(q['from'], q['to'], q['amount']);
      title = 'Результат конвертации';

      if (result is ConvSuccess) {
        content = '${q['amount'] ?? ''} ${q['from'] ?? ''} = ${result.value.toStringAsFixed(2)} ${q['to'] ?? ''}';
      } else if (result is ConvFailure) {
        content = 'Ошибка: ${result.message}';
        errorWidget = Text(
          'Проверьте данные',
          style: TextStyle(color: Theme.of(context).colorScheme.error),
        );
      } else {
        content = 'Неизвестная ошибка';
      }
    } else {
      title = 'Ошибка';
      content = 'Неизвестный тип';
    }

    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (errorWidget != null) errorWidget,
              const SizedBox(height: 16),
              Text(
                content,
                style: Theme.of(context).textTheme.headlineSmall,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              FilledButton(
                onPressed: () {
                  if (type == 'calculator') {
                    context.go('/calculator');
                  } else if (type == 'converter') {
                    context.go('/converter');
                  } else {
                    context.go('/');
                  }
                },
                child: const Text('Назад'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}