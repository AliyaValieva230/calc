import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Главная')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            FilledButton(
              onPressed: () => context.go('/calculator'),
              child: const Text('Калькулятор'),
            ),
            const SizedBox(height: 16),
            FilledButton(
              onPressed: () => context.go('/converter'),
              child: const Text('Конвертер валют'),
            ),
          ],
        ),
      ),
    );
  }
}