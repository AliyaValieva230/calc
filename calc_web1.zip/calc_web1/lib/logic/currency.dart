sealed class ConvResult {}

class ConvSuccess extends ConvResult {
  final double value;
  ConvSuccess(this.value);
}

class ConvFailure extends ConvResult {
  final String message;
  ConvFailure(this.message);
}

final Map<String, double> _rates = {
  'USD': 1.0,
  'EUR': 0.85,
  'GBP': 0.75,
  'JPY': 110.0,
  'CNY': 6.45,
  'RUB': 73.0,
};

ConvResult convertCurrency(String? from, String? to, String? amountStr) {
  if (from == null || to == null || amountStr == null) {
    return ConvFailure('Отсутствуют параметры валют или суммы');
  }
  final amount = double.tryParse(amountStr.replaceAll(',', '.'));
  if (amount == null) {
    return ConvFailure('Сумма должна быть числом');
  }
  if (amount < 0) {
    return ConvFailure('Сумма не может быть отрицательной');
  }
  final fromRate = _rates[from];
  final toRate = _rates[to];
  if (fromRate == null || toRate == null) {
    return ConvFailure('Неизвестная валюта');
  }
  final result = amount * (toRate / fromRate);
  return ConvSuccess(result);
}