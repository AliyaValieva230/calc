sealed class CalcResult {}

class CalcSuccess extends CalcResult {
  final double value;
  CalcSuccess(this.value);
}

class CalcFailure extends CalcResult {
  final String message;
  CalcFailure(this.message);
}

CalcResult calculate(String? rawA, String? rawOp, String? rawB) {
  final a = double.tryParse(rawA?.replaceAll(',', '.') ?? '');
  final b = double.tryParse(rawB?.replaceAll(',', '.') ?? '');
  if (a == null || b == null) {
    return CalcFailure('Переданы не числа');
  }
  switch (rawOp) {
    case '+':
      return CalcSuccess(a + b);
    case '-':
      return CalcSuccess(a - b);
    case '*':
      return CalcSuccess(a * b);
    case '/':
      if (b == 0) return CalcFailure('Делить нельзя на 0');
      return CalcSuccess(a / b);
    default:
      return CalcFailure('Неизвестная операция');
  }
}