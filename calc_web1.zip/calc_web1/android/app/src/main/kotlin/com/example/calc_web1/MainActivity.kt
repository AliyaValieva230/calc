package com.example.calc_web1

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
